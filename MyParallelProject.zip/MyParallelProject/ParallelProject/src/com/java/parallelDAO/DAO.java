package com.java.parallelDAO;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.java.parallelBean.Bean;
import com.java.parallelBean.TransBean;
public class DAO implements DAOI {
	HashMap<Long, Bean> hm1=new HashMap<Long, Bean>();
	long bacc;
	long dep2;
	long w2,q1,q2;
	long i=10000;
	HashMap<TransBean,Long> hmt =new HashMap<TransBean,Long>();
	ArrayList<TransBean> a1;
	
	public long service1(Bean b) {
		this.bacc=b.getBacc();
		hm1.put(bacc, b);
		
		if(hm1.containsKey(bacc))
		{
			return bacc;
		}
		else
			return 0;
	}
	public long showbalance(long bacc2,String password1) {
		Bean b1=(Bean) hm1.get(bacc2);
		if(b1==null) {
			throw new AccountNotFoundException("Invalid account number");
		}
		else {
			long bal=b1.getBal();
			return bal;
		}
	}
	
	public long deposit1(long account2, String password2, long dep1) {
		if(hm1.containsKey(account2))
		{
			Bean b1=(Bean) hm1.get(account2);
			if(b1.getPassword().equals(password2))
			{
				dep2=b1.getBal() + dep1;
				b1.setBal(dep2);
				SimpleDateFormat ft = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
						Date d=new Date();
					  TransBean tb=new TransBean();
					  tb.setAccountnumber(account2);
					  tb.setAmount(dep1);
					  tb.setTransid(i++);
					  tb.setTranstype("deposit");
					  tb.setTransdate(ft.format(d));
				      hmt.put(tb,account2);
			}
		}
		return dep2;
	}
	public long withdraw(long account3, String password3, long w1) {
		if(hm1.containsKey(account3))
		{
			Bean b1=(Bean) hm1.get(account3);
			if(b1.getPassword().equals(password3))
			{
				w2=b1.getBal() - w1;
				b1.setBal(w2);
				SimpleDateFormat ft = 
					      new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
						Date d=new Date();
					  TransBean tb=new TransBean();
					  tb.setAccountnumber(account3);
					  tb.setAmount(w1);
					  tb.setTransid(i++);
					  tb.setTranstype("deposit");
					  tb.setTransdate(ft.format(d));
				      hmt.put(tb,account3);
			}
		}
		return w2;
	}
	public long fund(long account4, long account5, String password4, long f1) {
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		Bean bal1=(Bean) hm1.get(account4);
		Bean bal2=(Bean) hm1.get(account5);
		q1=bal1.getBal()-f1;
		q2=bal2.getBal()+f1;
		bal1.setBal(q1);
		bal2.setBal(q2);
		SimpleDateFormat ft = 
			      new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
				Date d=new Date();
			  TransBean tb=new TransBean();
			  tb.setAccountnumber(account5);
			  tb.setAmount(f1);
			  tb.setTransid(i++);
			  tb.setTranstype("deposit");
			  tb.setTransdate(ft.format(d));
		      hmt.put(tb,account5);
		return q1;
	}
	public boolean validation(long account4, String password4) {
		if(hm1.containsKey(account4));
		{
			Bean b=(Bean) hm1.get(account4);
					if(b.getPassword().equals(password4)) {
						return true;
					}
		}
		return false;
	}
	public boolean validation1(long account4, String password4, long account5) {
		if(hm1.containsKey(account4)&&hm1.containsKey(account5));
		{
			Bean b=(Bean) hm1.get(account4);
					if(b.getPassword().equals(password4)) {
						return true;
					}
		}
		return false;
	}
	
	public List<TransBean> trans() {
		List<TransBean> a1=new ArrayList<TransBean>(hmt.keySet());
		return a1;
	}

	}
	
	
	

